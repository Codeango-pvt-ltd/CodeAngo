// App.js



import React, { useState } from 'react';
import './App.css';
import TopRatedCourses from './TopRatedCourses';
import NewAddedCourses from './NewAddedCourses';
import HighRatedCourses from './HighRatedCourses';


const App = () => {
  const courseData = [
    {
      category: 'Programming',
      courses: [
        { id: 1, title: 'Introduction to React', image: 'logo.svg', rating: 4.5, dateAdded: '2023-01-01' },
        { id: 2, title: 'Advanced JavaScript', image: 'advanced_js.jpg', rating: 4.8, dateAdded: '2023-02-15' },
      ],
    },
    {
      category: 'Design',
      courses: [
        { id: 3, title: 'UI/UX Basics', image: 'ui_ux_basics.jpg', rating: 4.2, dateAdded: '2023-03-10' },
        { id: 4, title: 'Responsive Web Design', image: 'responsive_design.jpg', rating: 4.7, dateAdded: '2023-04-05' },
      ],
    },
  ];

  const getTopRatedCourses = (courseData) => {
    const allCourses = courseData.reduce((acc, category) => acc.concat(category.courses), []);
    return allCourses.sort((a, b) => b.rating - a.rating).slice(0, 3);
  };

  const getNewAddedCourses = (courseData) => {
    const allCourses = courseData.reduce((acc, category) => acc.concat(category.courses), []);
    return allCourses.sort((a, b) => new Date(b.dateAdded) - new Date(a.dateAdded)).slice(0, 3);
  };

  const getHighRatedCourses = (courseData) => {
    const allCourses = courseData.reduce((acc, category) => acc.concat(category.courses), []);
    return allCourses.sort((a, b) => b.rating - a.rating).slice(0, 3);

    
  };

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedCourse, setSelectedCourse] = useState(null);

  const handleCategoryChange = (event) => {
    const selectedValue = event.target.value;
    setSelectedCategory(selectedValue);
    setSelectedCourse(null); // Reset selected course when changing category
    
  };
  const [searchQuery, setSearchQuery] = useState('');

  // Handler function for the search button click
  const handleSearch = () => {
    // Implement your search logic here
    console.log('Searching for:', searchQuery);
    // You can perform additional actions like making an API call or updating state based on the searchQuery
  };

  

  return (
    <div className="container">
      <div className="sidebar">
        
        <h1 style={{textAlign:'center',fontFamily:'initial',fontSize:'50px',backgroundColor:'GrayText'}}>Course </h1>
        <div style={{textAlign:'center'}}>
      {/* Input field for search query */}
      <input
        type="text"
        placeholder="Enter your search query"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />

      {/* Search button */}
      <button  onClick={handleSearch}>Search</button>

      {/* Additional content can be added here */}
    </div>

        <h2 style={{textAlign:'center', fontSize:'50px'}}>Choose a category to find your course</h2>
       
        <p style={{textAlign:'center', fontSize:'30px'}}>100+ Live online courses chosen by 50000+ working professionals</p>
        <button style={styles.viewDetailsButton} onClick={() => alert(`View details for ${App.title}`)}>
                All courses
              </button>

        <button style={styles.viewDetailsButton} onClick={() => alert(`View details for ${App.title}`)}>
                cloud computing
              </button>

        <button style={styles.viewDetailsButton} onClick={() => alert(`View details for ${App.title}`)}>
                Devops
              </button>
              <button style={styles.viewDetailsButton} onClick={() => alert(`View details for ${App.title}`)}>
                Data science
              </button>
              <button style={styles.viewDetailsButton} onClick={() => alert(`View details for ${App.title}`)}>
                Cyber Security
              </button>
              <button style={styles.viewDetailsButton} onClick={() => alert(`View details for ${App.title}`)}>
                Others
              </button>




        {/* <form>
          <select value={selectedCategory} onChange={handleCategoryChange}>
            <option value="All">All</option>
            {courseData.map((category) => (
              <option key={category.category} value={category.category}>
                {category.category}
              </option>
            ))}
          </select>
        </form> */}

      </div>
      

      
      {selectedCourse && (
        <div className="content" style={styles.content}>
          <h2>Selected Course</h2>
          <p>Title: {selectedCourse.title}</p>
          <p>Rating: {selectedCourse.rating}</p>
          <p>Date Added: {selectedCourse.dateAdded}</p>
        </div>
      )}
      <TopRatedCourses courses={getTopRatedCourses(courseData)} />
      <NewAddedCourses courses={getNewAddedCourses(courseData)} />
      <HighRatedCourses courses={getHighRatedCourses(courseData)} />
    </div>
    
    
  );
};

const styles = {
  container: {
    display: 'flex',
    position: 'relative',
    left: '231px',
  },
  slider: {
    width: '50px',
    backgroundColor: '#333',
    color: '#fff',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    position: 'absolute',
    left: '0',
    top: '10px',
  },
  content: {
    flex: 1,
    marginLeft: '50px',
  },
  viewDetailsButton: {
    backgroundColor: '#007BFF',
    color: '#fff',
    padding: '10px 20px',
    border: 'none',
    cursor: 'pointer',
    fontSize: '16px',
    borderRadius: '5px',
    transition: 'background-color 0.3s ease-in-out',
    marginTop: '10px',
    margin: '10px',
    padding: '10px'
  },
  viewDetailsButtonHover: {
    backgroundColor: '#0056b3',
  },
};




export default App;
